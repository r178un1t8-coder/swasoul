CONNECTWORLD WORKSPACE V2.0
===========================

Open index.html in a modern browser.

V2.0 features:
- Create posts and like posts
- Edit and delete posts created under the current local profile
- Add local comments and view comment counts
- Edit the local profile
- Create and join sample communities
- Create events and mark interest
- Search posts, communities and events
- Dark brown / warm orange theme inspired by the selected original ConnectWorld designs

Data is stored only in this browser using localStorage. It does not sync to other
users or devices. Authentication, a shared database, live messaging and server-side
moderation are not connected. Do not enter real passwords, identity documents,
precise location or other sensitive information.
