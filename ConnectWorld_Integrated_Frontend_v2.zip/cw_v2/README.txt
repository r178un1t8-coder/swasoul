CONNECTWORLD — INTEGRATED FRONTEND V2.0
======================================

START HERE
----------
Open index.html to browse all 55 original ConnectWorld screen prototypes.
Choose “Open interactive workspace” to use the enhanced local MVP.

V2.0 WORKSPACE UPGRADES
-----------------------
- Keeps the existing MVP page structure and feature set.
- Applies a dark brown / warm orange visual palette inspired by the selected original 55-screen design family.
- Adds Edit and Delete actions to posts created under the current local profile.
- Adds local comments with a visible comment count.
- Improves search across posts, communities and events.
- Keeps posts, comments, likes, profile, communities and events in browser localStorage.

PRESERVED ASSETS
----------------
- All 55 original screen prototype folders are included.
- Original screen images and individual code.html prototype files are preserved.
- workspace/index.html is the enhanced MVP.

IMPORTANT LIMITATIONS
---------------------
This is still a front-end prototype, not a public multi-user social network.
Data remains local to the browser/device. There is no real authentication,
shared database, live messaging, server-side authorization, or moderation backend.
Prototype screens are not automatically wired to live services. Do not enter
real identity documents, passwords, precise location, or other sensitive data.

ANDROID TESTING
---------------
1. Download and extract this ZIP.
2. Open index.html to browse the 55 designs.
3. Tap “Open interactive workspace” to test the local MVP.
4. For hosting, upload the extracted folder contents while preserving all folders.
   Keep the root index.html at the published site root.
