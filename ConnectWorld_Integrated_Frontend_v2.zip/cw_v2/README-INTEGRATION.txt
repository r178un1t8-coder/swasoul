CONNECTWORLD — INTEGRATED PROJECT PACKAGE
========================================

WHAT IS INCLUDED
----------------
1. Original public design showcase at the project root (index.html).
2. The 55 supplied screen prototypes and their original screen images, preserved in their original folders.
3. The existing interactive MVP at workspace/index.html.
4. A link from the original showcase to the interactive workspace.

HOW TO OPEN
-----------
- Open index.html to browse the original 55 screen designs.
- Choose “Open interactive workspace” to use the existing MVP features.
- Upload the CONTENTS of this folder to a static host; keep the folder structure intact.

FUNCTIONAL MVP FEATURES
-----------------------
- Create posts and like posts
- Local profile editing
- Create and join communities
- Create events and mark interest
- Search the sample content

IMPORTANT: WHAT IS NOT LIVE YET
------------------------------
This is an integrated front-end prototype, NOT a fully launched multi-user social network.
The MVP stores posts, profile, communities and events in the current browser's localStorage.
That means data does not sync across users or devices. There is no real authentication,
shared database, live messaging, or server-side moderation. The 55 screen prototypes
remain visual prototype pages; they have not all been wired to live data or navigation.

SAFETY
------
Do not collect or upload real identity documents, selfies for verification, passwords,
recovery codes, precise home/school locations, or other sensitive personal information.
Before public multi-user launch, add secure authentication, database Row Level Security,
report/block tools, moderation, and privacy controls. For a teen-facing service, keep
stranger contact and location-sharing disabled by default and avoid public meet-up features.

DEPLOYMENT
----------
Keep index.html at the root. Upload the complete folder contents to your static host.
Do not upload private keys or credentials.
