# Design System Strategy: The Radiant Social Collective

This design system is engineered to bridge the gap between the high-octane energy of digital discovery and the grounded, tactile warmth of real-world community. It rejects the "flatness" of generic social apps in favor of a layered, editorial experience that feels premium yet deeply accessible.

## 1. Creative North Star: "The Luminous Hearth"
The "Luminous Hearth" philosophy drives every layout decision. We treat the interface not as a series of static screens, but as a warm, inviting environment. We use **Intentional Asymmetry**—such as off-center headline alignments and overlapping image containers—to break the "template" feel. By utilizing high-contrast typography scales (e.g., pairing a massive `display-lg` headline with a tight `label-sm` metadata tag), we create a sense of curated, editorial authority.

---

## 2. Color & Tonal Architecture
The palette is rooted in a deep, nocturnal base (`background: #1c0900`) to provide a high-end "creator" canvas, allowing our primary "Connection Orange" and secondary "Electric Blue" to vibrate with energy.

### The "No-Line" Rule
**Standard 1px borders are strictly prohibited.** To define sections, use background shifts or tonal transitions.
- **Surface Nesting:** Create depth by stacking. Place a `surface-container-low` card atop a `surface` background. For high-priority content, use `surface-bright`.
- **The Glass & Gradient Rule:** For floating navigation or modal overlays, use **Glassmorphism**. Apply `surface-variant` at 60% opacity with a `20px` backdrop blur. 
- **Signature Textures:** Use subtle linear gradients for primary CTAs, transitioning from `primary` (#ff9159) to `primary-container` (#ff7a30) at a 135-degree angle. This adds "soul" and prevents the UI from looking like a flat prototype.

---

## 3. Typography: The Editorial Voice
We utilize a dual-font strategy to balance high-energy social browsing with trustworthy community information.

*   **Display & Headlines (Plus Jakarta Sans):** A modern, geometric sans with a sophisticated personality. Used for "High-Energy" moments—event titles, user names, and bold callouts.
    *   *Scale:* `display-lg` (3.5rem) for hero moments; `headline-md` (1.75rem) for standard section titles.
*   **Body & Labels (Be Vietnam Pro):** A highly legible, friendly sans-serif that retains a "rounded" approachable feel without sacrificing professional polish.
    *   *Scale:* `body-lg` (1rem) for social captions; `label-md` (0.75rem) for utility text and timestamps.

**Rule:** Always pair a large headline with generous leading (1.4x) and significant tracking-in (-0.02em) to give it a custom, high-end feel.

---

## 4. Elevation, Depth & The "Ghost Border"
We move away from traditional Material shadows. Hierarchy is achieved through **Tonal Layering**.

*   **The Layering Principle:** 
    *   Level 0: `surface` (The Base)
    *   Level 1: `surface-container-low` (Secondary content sections)
    *   Level 2: `surface-container` (Primary cards/feed items)
*   **Ambient Shadows:** When a "lift" is required (e.g., a floating Action Button), use a shadow color derived from `on-surface` at 6% opacity with a `32px` blur and `12px` Y-offset. It should feel like a soft glow, not a dark stain.
*   **The Ghost Border:** If a container sits on a background of the same tone, use a "Ghost Border": the `outline-variant` token at **15% opacity**. This provides just enough definition for accessibility while maintaining the "No-Line" aesthetic.

---

## 5. Signature Components

### Buttons & Interaction
*   **Primary:** Uses the Primary-to-Container gradient. Corner radius: `xl` (3rem/pill-shape).
*   **Secondary/Ghost:** A semi-transparent `secondary-container` (60% opacity) with a `backdrop-blur`. This ensures the energetic "Electric Blue" feels integrated into the dark theme.
*   **Haptic Feedback:** Every interaction must feel "social-first"—fast, bouncy, and responsive.

### Content Cards (The "Connection Card")
*   **Design:** Forbid divider lines. Use `spacing-6` (1.5rem) of vertical white space to separate content chunks.
*   **Corner Radius:** `md` (1.5rem / 24px) for the outer container; `sm` (0.5rem / 8px) for nested elements like media tags.
*   **Media:** Images should bleed to the edge of the card or use asymmetric cropping (e.g., top-left corner rounded at `xl`, bottom-right at `md`).

### Social Chips
*   **Action Chips:** Use `tertiary-container` with `on-tertiary-container` text. These should look like "candy"—highly clickable, vibrant, and inviting.

### Glass Overlays
*   **Contextual Modals:** Always use a 70% opacity `surface-container-highest` with a heavy `backdrop-blur`. This maintains the "social feed" context underneath while focusing the user on the "real-world meetup" details.

---

## 6. Do’s and Don’ts

### Do
*   **Do** overlap elements. An image should slightly "break" the container of the text block next to it to create an editorial, non-grid feel.
*   **Do** use `primary` orange for "Warmth/Connection" (Meetups, Messaging) and `secondary` blue for "Energy/Discovery" (Feed, Video).
*   **Do** prioritize breathing room. If in doubt, increase the spacing token by one level (e.g., move from `spacing-6` to `spacing-8`).

### Don’t
*   **Don’t** use pure black (#000000) for backgrounds. Stick to the warm, chocolate-toned `background` (#1c0900) to keep the vibe "cozy."
*   **Don’t** use 1px solid white or grey lines. They break the immersion and make the app look like a utility, not an experience.
*   **Don’t** use sharp corners. Everything must feel "softly rounded" to encourage a friendly, community-focused atmosphere.